# Forgely (Android)

Describe an app, and Forgely writes the full Android project for you.

1. Push these files to a new GitHub repo (main branch).
2. GitHub Actions builds the APK: Actions > latest run > Artifacts > forgely-debug-apk.
3. Install it on your phone, open it, and paste your free Gemini API key (aistudio.google.com) when asked.

Logo files are in `assets/` (`logo.png`, `store-icon-512.png`).
