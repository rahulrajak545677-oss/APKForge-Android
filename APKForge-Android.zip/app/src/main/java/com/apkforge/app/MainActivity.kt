package com.apkforge.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

val CYAN = Color(0xFF22D3EE)
val VIOLET = Color(0xFFA78BFA)

const val SYS = """You are the engine of an Android app builder and a friendly voice assistant. Follow the user's request literally: build exactly what they describe, add nothing extra, change nothing they did not ask for, no lectures, no questions (pick the simplest default if a detail is missing). If the user is only chatting or asking something, reply with one SAY line and no files. If the message contains Gradle or build errors, fix only what the errors require.

Project: Kotlin + Jetpack Compose, package com.generated.app. Build files already exist (compileSdk 34, minSdk 24, Compose BOM 2024.06, Material3, material-icons-extended, activity-compose, core-ktx, lifecycle-runtime-ktx). Do not output build files and use no other libraries. Output only files under app/src/main/: AndroidManifest.xml (theme must be @android:style/Theme.Material.Light.NoActionBar, MainActivity exported as launcher, only permissions truly needed), Kotlin files under app/src/main/java/com/generated/app/, and res files if needed. Complete imports, no placeholders, code must compile first try. Output the full contents of every file you touch.

Format, nothing else: first line "SAY: <one short friendly spoken sentence>", then for each file a line "=== FILE: path ===" followed by the contents, with no code fences."""

enum class St { Idle, Listening, Thinking, Speaking }
data class Msg(val me: Boolean, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

fun callApi(key: String, prompt: String): String {
    val body = JSONObject()
        .put("model", "claude-sonnet-5-5")
        .put("max_tokens", 16000)
        .put("system", SYS)
        .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
    val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
    c.requestMethod = "POST"
    c.connectTimeout = 30000
    c.readTimeout = 300000
    c.doOutput = true
    c.setRequestProperty("x-api-key", key)
    c.setRequestProperty("anthropic-version", "2023-06-01")
    c.setRequestProperty("content-type", "application/json")
    c.outputStream.use { it.write(body.toString().toByteArray()) }
    val ok = c.responseCode in 200..299
    val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
    if (!ok) throw Exception("API error " + c.responseCode + ": " + txt.take(200))
    val arr = JSONObject(txt).getJSONArray("content")
    val sb = StringBuilder()
    for (i in 0 until arr.length()) {
        val b = arr.getJSONObject(i)
        if (b.optString("type") == "text") sb.append(b.getString("text"))
    }
    return sb.toString()
}

fun parse(t: String): Pair<String, Map<String, String>> {
    var say = ""
    val f = LinkedHashMap<String, String>()
    var cur: String? = null
    val buf = StringBuilder()
    fun flush() {
        cur?.let { f[it] = buf.toString().trim() + "\n" }
        buf.clear()
    }
    val re = Regex("^=== FILE: (.+?) ===\\s*$")
    for (l in t.lines()) {
        val m = re.find(l)
        if (m != null) {
            flush()
            cur = m.groupValues[1].trim()
        } else if (cur != null) {
            if (!l.startsWith("```")) buf.appendLine(l)
        } else if (l.startsWith("SAY:")) {
            say = l.substring(4).trim()
        }
    }
    flush()
    return say to f
}

@Composable
fun Orb(st: St, onClick: () -> Unit) {
    val tr = rememberInfiniteTransition(label = "orb")
    val ms = when (st) { St.Idle -> 2200; St.Listening -> 700; St.Thinking -> 1000; St.Speaking -> 450 }
    val s by tr.animateFloat(
        1f, if (st == St.Idle) 1.05f else 1.16f,
        infiniteRepeatable(tween(ms), RepeatMode.Reverse), label = "s"
    )
    val colors = if (st == St.Listening) listOf(Color(0xFF34D399), CYAN) else listOf(CYAN, VIOLET)
    Box(
        Modifier.size(96.dp).scale(s)
            .background(Brush.radialGradient(colors), CircleShape)
            .clickable(onClick = onClick)
    )
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("p", Context.MODE_PRIVATE) }
    var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var showKey by remember { mutableStateOf(key.isEmpty()) }
    var voice by remember { mutableStateOf(true) }
    var st by remember { mutableStateOf(St.Idle) }
    var input by remember { mutableStateOf("") }
    var viewing by remember { mutableStateOf<String?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    val msgs = remember {
        mutableStateListOf(Msg(false, "Hi! Tell me the app you want, by typing or tapping the orb to talk, and I'll write the full Android project."))
    }
    val project = remember { mutableStateMapOf<String, String>() }
    val list = rememberLazyListState()

    DisposableEffect(Unit) {
        lateinit var t: TextToSpeech
        t = TextToSpeech(ctx) { s -> if (s == TextToSpeech.SUCCESS) t.setLanguage(Locale.getDefault()) }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { st = St.Speaking }
            override fun onDone(id: String?) { st = St.Idle }
            override fun onError(id: String?) { st = St.Idle }
        })
        tts = t
        onDispose { t.shutdown() }
    }
    LaunchedEffect(msgs.size) { list.animateScrollToItem(msgs.lastIndex) }

    fun speak(t: String) {
        st = St.Idle
        val engine = tts
        if (voice && engine != null) engine.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    fun send(text: String) {
        val m = text.trim()
        if (m.isEmpty() || st == St.Thinking) return
        if (key.isEmpty()) { showKey = true; return }
        input = ""
        msgs.add(Msg(true, m))
        st = St.Thinking
        val files = project.entries.joinToString("\n") { "=== FILE: " + it.key + " ===\n" + it.value }
        val prompt = "CURRENT PROJECT FILES:\n" + files.ifEmpty { "(none yet)" } + "\n\nUSER REQUEST:\n" + m
        scope.launch {
            try {
                val out = withContext(Dispatchers.IO) { callApi(key, prompt) }
                val (say, found) = parse(out)
                var n = 0
                for ((p, c) in found) {
                    if (p.startsWith("app/src/main/") && !p.contains("..")) { project[p] = c; n++ }
                }
                val line = say.ifEmpty { if (n > 0) "Done. Your app files are ready." else "Okay." }
                msgs.add(Msg(false, line))
                speak(line)
            } catch (e: Exception) {
                msgs.add(Msg(false, "Error: " + (e.message ?: "something went wrong")))
                st = St.Idle
            }
        }
    }

    fun listen() {
        tts?.stop()
        val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                sr.destroy()
                if (t != null) send(t) else st = St.Idle
            }
            override fun onError(e: Int) {
                sr.destroy()
                st = St.Idle
                msgs.add(Msg(false, "I couldn't hear that. Tap the orb and try again."))
            }
            override fun onReadyForSpeech(p: Bundle?) { st = St.Listening }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        sr.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        )
    }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) listen() }

    fun mic() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            msgs.add(Msg(false, "Voice input isn't available on this device. Typing works fine."))
            return
        }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) listen()
        else perm.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun share() {
        try {
            val dir = File(ctx.cacheDir, "shared").apply { mkdirs() }
            val f = File(dir, "android-app-project.zip")
            ZipOutputStream(f.outputStream()).use { z ->
                for ((p, c) in TEMPLATE + project) {
                    z.putNextEntry(ZipEntry(p))
                    z.write(c.toByteArray())
                    z.closeEntry()
                }
            }
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(i, "Save project"))
        } catch (e: Exception) {
            msgs.add(Msg(false, "Couldn't create the zip: " + e.message))
        }
    }

    if (showKey) {
        AlertDialog(
            onDismissRequest = { if (key.isNotEmpty()) showKey = false },
            title = { Text("Anthropic API key") },
            text = {
                Column {
                    Text("Get a key at console.anthropic.com. It is stored only on this device, and usage is billed to your account.", fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = key, onValueChange = { key = it.trim() },
                        singleLine = true, placeholder = { Text("sk-ant-...") },
                        visualTransformation = PasswordVisualTransformation()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    prefs.edit().putString("key", key).apply()
                    showKey = key.isEmpty()
                }) { Text("Save") }
            }
        )
    }

    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF070914), Color(0xFF111638))))
            .padding(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("⚡ APK FORGE", color = CYAN, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { voice = !voice; if (!voice) tts?.stop() }) { Text(if (voice) "🔊 Voice" else "🔇 Muted") }
            TextButton(onClick = { showKey = true }) { Text("Key") }
        }
        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Orb(st) { mic() }
            Spacer(Modifier.height(14.dp))
            Text(
                when (st) {
                    St.Idle -> "Tap the orb to talk"
                    St.Listening -> "Listening…"
                    St.Thinking -> "Building…"
                    St.Speaking -> "Speaking…"
                },
                color = Color(0xFF8B93B8), fontSize = 12.sp
            )
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.me) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(
                        m.text, color = Color.White,
                        modifier = Modifier.widthIn(max = 300.dp)
                            .background(if (m.me) Color(0xFF2A3170) else Color(0xFF161B3D), RoundedCornerShape(14.dp))
                            .padding(10.dp)
                    )
                }
            }
        }
        if (project.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(project.keys.toList()) { p ->
                        OutlinedButton(onClick = { viewing = if (viewing == p) null else p }) {
                            Text(p.removePrefix("app/src/main/").substringAfterLast('/'), fontSize = 11.sp)
                        }
                    }
                }
                val v = viewing
                if (v != null && project[v] != null) {
                    Text(
                        project[v] ?: "", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = Color(0xFFB8C0E8),
                        modifier = Modifier.fillMaxWidth().heightIn(max = 140.dp).padding(vertical = 6.dp).verticalScroll(rememberScrollState())
                    )
                }
                Button(onClick = { share() }, modifier = Modifier.fillMaxWidth()) { Text("⬇ Save project (.zip)") }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Describe the app you want…") }, maxLines = 4
            )
            Spacer(Modifier.width(6.dp))
            Button(onClick = { send(input) }, enabled = st != St.Thinking) { Text("➤") }
        }
    }
}
