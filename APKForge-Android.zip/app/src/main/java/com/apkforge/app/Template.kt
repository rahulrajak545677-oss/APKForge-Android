package com.apkforge.app

val TEMPLATE: Map<String, String> = mapOf(
    "settings.gradle.kts" to """pluginManagement{repositories{google();mavenCentral();gradlePluginPortal()}}
dependencyResolutionManagement{repositories{google();mavenCentral()}}
rootProject.name="GeneratedApp"
include(":app")
""",
    "build.gradle.kts" to """plugins{
id("com.android.application") version "8.5.2" apply false
id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
""",
    "gradle.properties" to """android.useAndroidX=true
org.gradle.jvmargs=-Xmx2g
kotlin.code.style=official
""",
    "app/build.gradle.kts" to """plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{
namespace="com.generated.app"
compileSdk=34
defaultConfig{applicationId="com.generated.app";minSdk=24;targetSdk=34;versionCode=1;versionName="1.0"}
buildFeatures{compose=true}
composeOptions{kotlinCompilerExtensionVersion="1.5.14"}
compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
kotlinOptions{jvmTarget="17"}
}
dependencies{
implementation(platform("androidx.compose:compose-bom:2024.06.00"))
implementation("androidx.core:core-ktx:1.13.1")
implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.3")
implementation("androidx.activity:activity-compose:1.9.0")
implementation("androidx.compose.ui:ui")
implementation("androidx.compose.ui:ui-graphics")
implementation("androidx.compose.foundation:foundation")
implementation("androidx.compose.material3:material3")
implementation("androidx.compose.material:material-icons-extended")
}
""",
    ".github/workflows/build.yml" to """name: Build APK
on:
  push:
    branches: [main]
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - uses: android-actions/setup-android@v3
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: "8.7"
      - run: gradle assembleDebug --no-daemon
      - uses: actions/upload-artifact@v4
        with:
          name: app-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
""",
    "README.md" to """Push these files to a GitHub repo (main branch). GitHub Actions builds the APK. Download it from Actions > latest run > Artifacts > app-debug-apk, then install it on your phone.
""",
)
