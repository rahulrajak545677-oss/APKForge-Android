APK Forge (Android). Push these files to a new GitHub repo (main branch).
GitHub Actions builds the APK: Actions > latest run > Artifacts > app-debug-apk.
Install it on your phone, open it, and paste your Anthropic API key when asked.
