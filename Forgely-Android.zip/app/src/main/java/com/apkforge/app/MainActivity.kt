package com.apkforge.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

// ---- Forgely design tokens
val CYAN = Color(0xFF22D3EE)
val VIOLET = Color(0xFFA78BFA)
val EMERALD = Color(0xFF34D399)
val BG_TOP = Color(0xFF05070F)
val BG_BOTTOM = Color(0xFF0E1330)
val SURFACE = Color(0xFF121833)
val SURFACE_HI = Color(0xFF1A2145)
val STROKE = Color(0x26FFFFFF)
val TEXT_HI = Color(0xFFEEF1FF)
val TEXT_LO = Color(0xFF8A93B8)
val INK = Color(0xFF06081A)
val ACCENT = Brush.horizontalGradient(listOf(CYAN, VIOLET))
val USER_BUBBLE = Brush.linearGradient(listOf(Color(0xFF3A4BE0), Color(0xFF7C3AED)))

const val SYS = """You are the engine of an Android app builder and a friendly voice assistant. Follow the user's request literally: build exactly what they describe, add nothing extra, change nothing they did not ask for, no lectures, no questions (pick the simplest default if a detail is missing). If the user is only chatting or asking something, reply with one SAY line and no files. If the message contains Gradle or build errors, fix only what the errors require.

Project: Kotlin + Jetpack Compose, package com.generated.app. Build files already exist (compileSdk 34, minSdk 24, Compose BOM 2024.06, Material3, material-icons-extended, activity-compose, core-ktx, lifecycle-runtime-ktx). Do not output build files and use no other libraries. Output only files under app/src/main/: AndroidManifest.xml (theme must be @android:style/Theme.Material.Light.NoActionBar, MainActivity exported as launcher, only permissions truly needed), Kotlin files under app/src/main/java/com/generated/app/, and res files if needed. Complete imports, no placeholders, code must compile first try. Output the full contents of every file you touch.

Format, nothing else: first line "SAY: <one short friendly spoken sentence>", then for each file a line "=== FILE: path ===" followed by the contents, with no code fences."""

enum class St { Idle, Listening, Thinking, Speaking }
data class Msg(val me: Boolean, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = CYAN, onPrimary = INK, secondary = VIOLET,
                    background = BG_TOP, surface = SURFACE, onSurface = TEXT_HI,
                    onBackground = TEXT_HI, surfaceVariant = SURFACE_HI, outline = STROKE
                )
            ) { App() }
        }
    }
}

fun callApi(key: String, model: String, prompt: String): String {
    val body = JSONObject()
        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYS))))
        .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
        .put("generationConfig", JSONObject().put("maxOutputTokens", 32000))
    val c = URL("https://generativelanguage.googleapis.com/v1beta/models/" + model.trim() + ":generateContent").openConnection() as HttpURLConnection
    c.requestMethod = "POST"
    c.connectTimeout = 30000
    c.readTimeout = 300000
    c.doOutput = true
    c.setRequestProperty("x-goog-api-key", key)
    c.setRequestProperty("content-type", "application/json")
    c.outputStream.use { it.write(body.toString().toByteArray()) }
    val ok = c.responseCode in 200..299
    val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
    if (!ok) throw Exception("API error " + c.responseCode + ": " + txt.take(200))
    val cands = JSONObject(txt).optJSONArray("candidates") ?: throw Exception("No answer returned. Try rephrasing.")
    val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts") ?: throw Exception("Empty answer. Try again.")
    val sb = StringBuilder()
    for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
    return sb.toString()
}

fun parse(t: String): Pair<String, Map<String, String>> {
    var say = ""
    val f = LinkedHashMap<String, String>()
    var cur: String? = null
    val buf = StringBuilder()
    fun flush() {
        cur?.let { f[it] = buf.toString().trim() + "\n" }
        buf.clear()
    }
    val re = Regex("^=== FILE: (.+?) ===\\s*$")
    for (l in t.lines()) {
        val m = re.find(l)
        if (m != null) {
            flush()
            cur = m.groupValues[1].trim()
        } else if (cur != null) {
            if (!l.startsWith("```")) buf.appendLine(l)
        } else if (l.startsWith("SAY:")) {
            say = l.substring(4).trim()
        }
    }
    flush()
    return say to f
}

@Composable
fun LogoMark(size: androidx.compose.ui.unit.Dp) {
    Box(
        Modifier.size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(Brush.linearGradient(listOf(Color(0xFF080B1F), Color(0xFF22196B), Color(0xFF5B2BC7))))
            .border(1.dp, STROKE, RoundedCornerShape(size * 0.28f)),
        contentAlignment = Alignment.Center
    ) {
        Image(painterResource(R.drawable.ic_logo_mark), contentDescription = "Forgely", modifier = Modifier.size(size * 1.12f))
    }
}

@Composable
fun Orb(st: St, onClick: () -> Unit) {
    val tr = rememberInfiniteTransition(label = "orb")
    val ms = when (st) { St.Idle -> 2400; St.Listening -> 800; St.Thinking -> 1100; St.Speaking -> 520 }
    val s by tr.animateFloat(
        1f, if (st == St.Idle) 1.04f else 1.1f,
        infiniteRepeatable(tween(ms), RepeatMode.Reverse), label = "s"
    )
    val pulse by tr.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(ms * 2), RepeatMode.Restart), label = "p"
    )
    val colors = if (st == St.Listening) listOf(EMERALD, CYAN) else listOf(CYAN, VIOLET)
    val glow = colors.first()
    val icon: ImageVector = when (st) {
        St.Idle -> Icons.Rounded.Mic
        St.Listening -> Icons.Rounded.GraphicEq
        St.Thinking -> Icons.Rounded.AutoAwesome
        St.Speaking -> Icons.Rounded.VolumeUp
    }
    Box(Modifier.size(156.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val base = size.minDimension / 2f
            for (i in 0..1) {
                val p = (pulse + i * 0.5f) % 1f
                drawCircle(color = glow.copy(alpha = (1f - p) * 0.30f), radius = base * (0.52f + 0.48f * p))
            }
            drawCircle(color = glow.copy(alpha = 0.10f), radius = base * 0.62f)
        }
        Box(
            Modifier.size(88.dp).scale(s)
                .clip(CircleShape)
                .background(Brush.linearGradient(colors))
                .border(1.dp, Color(0x55FFFFFF), CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = "Talk", tint = INK, modifier = Modifier.size(38.dp))
        }
    }
}

@Composable
fun StatusChip(st: St) {
    val label = when (st) {
        St.Idle -> "Tap the orb to talk"
        St.Listening -> "Listening…"
        St.Thinking -> "Forging your app…"
        St.Speaking -> "Speaking…"
    }
    val dot = when (st) {
        St.Idle -> TEXT_LO
        St.Listening -> EMERALD
        St.Thinking -> VIOLET
        St.Speaking -> CYAN
    }
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(SURFACE)
            .border(1.dp, STROKE, RoundedCornerShape(50))
            .padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(7.dp).background(dot, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(label, color = TEXT_HI, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Bubble(m: Msg) {
    if (m.me) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
            Text(
                m.text, color = Color.White, fontSize = 15.sp, lineHeight = 21.sp,
                modifier = Modifier.widthIn(max = 300.dp)
                    .background(USER_BUBBLE, RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }
    } else {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            LogoMark(28.dp)
            Spacer(Modifier.width(8.dp))
            Text(
                m.text, color = TEXT_HI, fontSize = 15.sp, lineHeight = 21.sp,
                modifier = Modifier.widthIn(max = 290.dp)
                    .background(SURFACE, RoundedCornerShape(6.dp, 20.dp, 20.dp, 20.dp))
                    .border(1.dp, STROKE, RoundedCornerShape(6.dp, 20.dp, 20.dp, 20.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
fun IconTile(icon: ImageVector, desc: String, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(RoundedCornerShape(14.dp)).background(SURFACE)
            .border(1.dp, STROKE, RoundedCornerShape(14.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, contentDescription = desc, tint = TEXT_HI, modifier = Modifier.size(20.dp)) }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("p", Context.MODE_PRIVATE) }
    var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "gemini-flash-latest") ?: "gemini-flash-latest") }
    var showKey by remember { mutableStateOf(key.isEmpty()) }
    var voice by remember { mutableStateOf(true) }
    var st by remember { mutableStateOf(St.Idle) }
    var input by remember { mutableStateOf("") }
    var viewing by remember { mutableStateOf<String?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    val msgs = remember {
        mutableStateListOf(Msg(false, "Hi! Tell me the app you want, by typing or tapping the orb to talk, and I'll write the full Android project."))
    }
    val project = remember { mutableStateMapOf<String, String>() }
    val list = rememberLazyListState()

    DisposableEffect(Unit) {
        lateinit var t: TextToSpeech
        t = TextToSpeech(ctx) { s -> if (s == TextToSpeech.SUCCESS) t.setLanguage(Locale.getDefault()) }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { st = St.Speaking }
            override fun onDone(id: String?) { st = St.Idle }
            override fun onError(id: String?) { st = St.Idle }
        })
        tts = t
        onDispose { t.shutdown() }
    }
    LaunchedEffect(msgs.size) { list.animateScrollToItem(msgs.lastIndex) }

    fun speak(t: String) {
        st = St.Idle
        val engine = tts
        if (voice && engine != null) engine.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    fun send(text: String) {
        val m = text.trim()
        if (m.isEmpty() || st == St.Thinking) return
        if (key.isEmpty()) { showKey = true; return }
        input = ""
        msgs.add(Msg(true, m))
        st = St.Thinking
        val files = project.entries.joinToString("\n") { "=== FILE: " + it.key + " ===\n" + it.value }
        val prompt = "CURRENT PROJECT FILES:\n" + files.ifEmpty { "(none yet)" } + "\n\nUSER REQUEST:\n" + m
        scope.launch {
            try {
                val out = withContext(Dispatchers.IO) { callApi(key, model, prompt) }
                val (say, found) = parse(out)
                var n = 0
                for ((p, c) in found) {
                    if (p.startsWith("app/src/main/") && !p.contains("..")) { project[p] = c; n++ }
                }
                val line = say.ifEmpty { if (n > 0) "Done. Your app files are ready." else "Okay." }
                msgs.add(Msg(false, line))
                speak(line)
            } catch (e: Exception) {
                msgs.add(Msg(false, "Error: " + (e.message ?: "something went wrong")))
                st = St.Idle
            }
        }
    }

    fun listen() {
        tts?.stop()
        val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                sr.destroy()
                if (t != null) send(t) else st = St.Idle
            }
            override fun onError(e: Int) {
                sr.destroy()
                st = St.Idle
                msgs.add(Msg(false, "I couldn't hear that. Tap the orb and try again."))
            }
            override fun onReadyForSpeech(p: Bundle?) { st = St.Listening }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        sr.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        )
    }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) listen() }

    fun mic() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            msgs.add(Msg(false, "Voice input isn't available on this device. Typing works fine."))
            return
        }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) listen()
        else perm.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun share() {
        try {
            val dir = File(ctx.cacheDir, "shared").apply { mkdirs() }
            val f = File(dir, "forgely-project.zip")
            ZipOutputStream(f.outputStream()).use { z ->
                for ((p, c) in TEMPLATE + project) {
                    z.putNextEntry(ZipEntry(p))
                    z.write(c.toByteArray())
                    z.closeEntry()
                }
            }
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(i, "Save project"))
        } catch (e: Exception) {
            msgs.add(Msg(false, "Couldn't create the zip: " + e.message))
        }
    }

    if (showKey) {
        val fieldColors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CYAN, unfocusedBorderColor = STROKE,
            focusedLabelColor = CYAN, unfocusedLabelColor = TEXT_LO,
            cursorColor = CYAN, focusedTextColor = TEXT_HI, unfocusedTextColor = TEXT_HI
        )
        AlertDialog(
            onDismissRequest = { if (key.isNotEmpty()) showKey = false },
            containerColor = SURFACE_HI,
            shape = RoundedCornerShape(28.dp),
            icon = { Icon(Icons.Rounded.VpnKey, contentDescription = null, tint = CYAN) },
            title = { Text("Connect Gemini", color = TEXT_HI, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Get a free key at aistudio.google.com (tap Get API key). It is stored only on this device.",
                        fontSize = 13.sp, color = TEXT_LO, lineHeight = 19.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = key, onValueChange = { key = it.trim() },
                        singleLine = true, label = { Text("API key") }, placeholder = { Text("AIza...") },
                        shape = RoundedCornerShape(14.dp), colors = fieldColors,
                        visualTransformation = PasswordVisualTransformation()
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = model, onValueChange = { model = it.trim() },
                        singleLine = true, label = { Text("Model") },
                        shape = RoundedCornerShape(14.dp), colors = fieldColors
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        prefs.edit().putString("key", key).putString("model", model).apply()
                        showKey = key.isEmpty()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CYAN, contentColor = INK),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("Save", fontWeight = FontWeight.Bold) }
            }
        )
    }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(BG_TOP, BG_BOTTOM)))
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(VIOLET.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(size.width * 0.5f, size.height * 0.12f),
                        radius = size.width * 0.95f
                    ),
                    radius = size.width * 0.95f,
                    center = Offset(size.width * 0.5f, size.height * 0.12f)
                )
            }
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
                .padding(horizontal = 16.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                LogoMark(42.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Forgely", color = TEXT_HI, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, letterSpacing = 0.5.sp)
                    Text("Describe it. Forge it. Ship it.", color = TEXT_LO, fontSize = 12.sp)
                }
                IconTile(if (voice) Icons.Rounded.VolumeUp else Icons.Rounded.VolumeOff, "Voice") {
                    voice = !voice; if (!voice) tts?.stop()
                }
                Spacer(Modifier.width(8.dp))
                IconTile(Icons.Rounded.VpnKey, "API key") { showKey = true }
            }

            Column(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Orb(st) { mic() }
                StatusChip(st)
            }

            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(), state = list,
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(msgs) { m -> Bubble(m) }
            }

            if (project.isEmpty() && msgs.size <= 1) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                    items(listOf("A habit tracker", "A pomodoro timer", "A tip calculator", "A flashcard quiz")) { s ->
                        Text(
                            s, color = TEXT_HI, fontSize = 13.sp,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(SURFACE)
                                .border(1.dp, STROKE, RoundedCornerShape(50))
                                .clickable { send("Build " + s.lowercase()) }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            if (project.isNotEmpty()) {
                Column(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(20.dp)).background(SURFACE)
                        .border(1.dp, STROKE, RoundedCornerShape(20.dp)).padding(12.dp)
                ) {
                    Text(
                        "PROJECT FILES · " + project.size, color = TEXT_LO, fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(project.keys.toList()) { p ->
                            val on = viewing == p
                            Row(
                                Modifier.clip(RoundedCornerShape(12.dp))
                                    .background(if (on) SURFACE_HI else Color.Transparent)
                                    .border(1.dp, if (on) CYAN else STROKE, RoundedCornerShape(12.dp))
                                    .clickable { viewing = if (on) null else p }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.Description, contentDescription = null, tint = if (on) CYAN else TEXT_LO, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(p.removePrefix("app/src/main/").substringAfterLast('/'), fontSize = 12.sp, color = TEXT_HI)
                            }
                        }
                    }
                    val v = viewing
                    if (v != null && project[v] != null) {
                        Text(
                            project[v] ?: "", fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 14.sp,
                            color = Color(0xFFB8C0E8),
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp).heightIn(max = 140.dp)
                                .clip(RoundedCornerShape(12.dp)).background(BG_TOP).padding(10.dp)
                                .verticalScroll(rememberScrollState())
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(14.dp))
                            .background(ACCENT).clickable { share() },
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Download, contentDescription = null, tint = INK, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Export project (.zip)", color = INK, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(28.dp)).background(SURFACE)
                    .border(1.dp, STROKE, RoundedCornerShape(28.dp))
                    .padding(start = 4.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                    placeholder = { Text("Describe the app you want…", color = TEXT_LO) }, maxLines = 4,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = CYAN, focusedTextColor = TEXT_HI, unfocusedTextColor = TEXT_HI
                    )
                )
                val canSend = st != St.Thinking && input.isNotBlank()
                Box(
                    Modifier.size(44.dp).clip(CircleShape)
                        .background(if (canSend) ACCENT else Brush.linearGradient(listOf(SURFACE_HI, SURFACE_HI)))
                        .clickable(enabled = canSend) { send(input) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "Send", tint = if (canSend) INK else TEXT_LO, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}
